# Delivery and Driver Allocation Management System

## Project overview

This pure Python, in-memory program manages drivers and delivery tasks. It supports automatic and direct allocation, deterministic pricing and earnings, a guarded delivery workflow, performance and zone reports, and a console dashboard. It uses no database, persistence, external packages, or service APIs.

## Architecture

All business functions receive their driver and/or delivery structures as arguments. They return a result dictionary with `success`, `message`, and `data`. The console demo prints these results separately.

- Validation: `to_number`, `validate_task`, and `validate_driver` check values and required fields.
- Allocation: `allocate_driver`, `assign_driver`, and `allocate_pending_tasks` select and assign drivers.
- Pricing and earnings: `calculate_delivery_charge` and `calculate_driver_earning` return component breakdowns.
- Workflow: `update_delivery_status` permits only forward status transitions and restores driver availability on completion.
- Reports: `driver_performance_report`, `zone_report`, and `additional_reports` return report data.
- Dashboard: `dashboard_data` calculates metrics and `render_dashboard` formats the required ASCII layout.
- Presentation: `main` demonstrates the system and prints report sections; calculations and state changes are handled by business functions.

## Data structures and ownership

Drivers are dictionaries keyed by driver ID. Deliveries are a list of dictionaries. A set collects unique zones, tuples hold fixed rate tiers, and comprehensions build filtered report data. `build_starter_drivers()` and `build_starter_deliveries()` return fresh structures each time. No mutable business data is shared at module scope. `CONFIG` contains defaults and functions do not modify it.

Invalid task records are returned in each report's `rejected_tasks` list and skipped. The first valid occurrence of an ID is used; later duplicate IDs are rejected. Active tasks (`assigned` or `picked_up`) require a known driver when functions validate a delivery collection against its drivers.

## Business rules

- Task zones and priorities are compared after trimming whitespace and uppercasing zones or lowercasing priorities. Valid priorities are `normal` and `urgent`.
- Distance accepts numbers and numeric strings, including zero. It rejects booleans, invalid text, NaN, infinity, and negatives. Order amount uses the same numeric formats but must be greater than zero.
- Driver availability must be exactly `True` or `False`; rating must be in the inclusive range 0 through 5.
- A driver is eligible only if available and in the task's zone. The highest rating wins; equal ratings use the lexicographically smallest driver ID.
- Batch allocation processes urgent tasks first, then normal tasks, sorting task IDs within each priority. A driver becomes busy upon assignment, so can hold only one active task.
- Delivery charge is a $5 base plus distance at $1/km through 5 km, $1.50/km above 5 through 10 km, or $2/km above 10 km. Urgent tasks receive a 25% surcharge on base plus distance charge.
- Driver earnings are a $3 base plus distance at $0.80/km through 5 km, $1.20/km above 5 through 10 km, or $1.50/km above 10 km. Orders of at least $150 add 10% of the base-plus-distance subtotal. Failed tasks earn $0. Only final money amounts are rounded to two decimals.
- `calculate_delivery_charge(..., **options)` accepts `base_charge` and `urgent_surcharge`. `calculate_driver_earning(..., **options)` accepts `driver_base`, `driver_bonus_percentage`, and `bonus_threshold`. Values must be finite nonnegative numeric values and cannot be booleans. An unknown option fails with its name. These options affect only that call.
- `calculate_total(*amounts)` validates and totals any number of numeric amounts.

## Workflow

`pending -> assigned -> picked_up -> delivered/failed`

The pending-to-assigned transition must use a direct or automatic assignment function. Generic status updates reject it. Completion as `delivered` or `failed` restores the driver's availability. Terminal tasks cannot be reprocessed.

## Reports and dashboard definitions

Driver reports include every driver, even if they have no tasks. Total assigned counts tasks allocated to that driver; completion rate is delivered divided by assigned, or 0% when there are no assignments. The report's distance and earnings totals include delivered tasks only; failed tasks earn zero.

The dashboard uses these definitions:

- Total Order Value: order amounts from all valid tasks.
- Total Delivery Charges: final delivery charges from delivered tasks only.
- Total Driver Earnings: earnings from delivered tasks only.
- Top Driver: most delivered tasks; then highest total earnings; then lowest driver ID. It is `N/A` when no driver has a delivered task.
- Highest Revenue Zone: greatest delivered delivery-charge revenue, with alphabetical tie-breaking. It is `N/A` when no positive delivered revenue exists.
- Average Delivery Distance: mean distance for all valid tasks, or 0.00 when none exist.
- Unassigned Tasks: pending tasks without a driver ID.

Zone reports include zones seen in either drivers or valid tasks. Revenue is based on delivered task charges and is sorted highest first, then alphabetically.

## Additional reports

`additional_reports` provides unique zones, tasks and revenue per zone, average order amount, longest delivery, highest value order, available and busy drivers, urgent deliveries, and unassigned tasks. Ties for longest delivery and highest value order use the lexicographically greatest task ID as a deterministic choice.

## LEGB demonstration

`make_rate_calculator` returns a closure: its inner function has local values, reads enclosing `tiers` and `base`, and references the global `CONFIG`. `explain_legb_demo` returns a small mapping showing local and enclosing variables, a global configuration value, and the built-in `len`. The inner `scope_name` shadows its enclosing name, demonstrating local variable shadowing.

## Testing

Run the assert-based test runner with:

```text
python3 test_delivery_system.py
```

Observed result from this workspace:

```text
Running tests...
PASS: test_fresh_starter_data
PASS: test_allocation_and_tie_break
PASS: test_allocation_validation_and_no_driver
PASS: test_batch_priority_and_multiple_tasks
PASS: test_pricing_tiers_zero_and_options
PASS: test_earnings_and_totals
PASS: test_validation_and_input_integrity
PASS: test_workflow_and_availability
PASS: test_reports_and_dashboard
All tests passed.
```

## Sample dashboard

The following output was observed by running `python3 delivery_system.py` after the demo sequence:

```text
========== DELIVERY DASHBOARD ==========
Total Tasks: 4
Pending: 1
Assigned: 1
Picked Up: 0
Delivered: 1
Failed: 1
Total Order Value: $450.00
Total Delivery Charges: $9.00
Total Driver Earnings: $6.20
Top Driver: D001
Highest Revenue Zone: A
Average Delivery Distance: 5.75 km
Unassigned Tasks:
- TASK004
========================================
```

## Assumptions and design decisions

- Input zone and priority normalization is applied during comparison; source task and driver values are not rewritten.
- Reports retain valid task records and give the caller validation reasons for rejected records instead of raising business-data exceptions.
- A missing `driver_id` on a pending task is treated like `None`; active tasks need a driver ID that exists in the supplied driver mapping.
- Delivery and earning calculations are available for any valid task record; the report and dashboard apply delivered-only rules where the specification requires them.
- The demo's extra zone C task remains pending because the starter drivers have no zone C driver.
- The code uses no imports in the implementation. Numeric string conversion catches `ValueError` in the single parsing helper.
