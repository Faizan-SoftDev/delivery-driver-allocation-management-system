"""In-memory delivery allocation and reporting functions."""

CONFIG = {
    "base_charge": 5.0,
    "urgent_surcharge": 0.25,
    "delivery_rates": (1.0, 1.5, 2.0),
    "driver_base": 3.0,
    "driver_rates": (0.8, 1.2, 1.5),
    "driver_bonus_percentage": 0.10,
    "bonus_threshold": 150.0,
}
VALID_STATUSES = ("pending", "assigned", "picked_up", "delivered", "failed")
TASK_FIELDS = ("id", "customer", "zone", "distance", "order_amount", "priority", "status")
DRIVER_FIELDS = ("name", "zone", "available", "rating")


def result(success, message, data=None):
    return {"success": success, "message": message, "data": data}


def to_number(value):
    """Convert supported numeric input; reject booleans, non-finite values, and invalid text."""
    if isinstance(value, bool):
        return False, None
    if isinstance(value, (int, float)):
        number = float(value)
    elif isinstance(value, str):
        try:
            number = float(value.strip())
        except ValueError:  # Numeric text is user data and may not be convertible.
            return False, None
    else:
        return False, None
    if number != number or number in (float("inf"), float("-inf")):
        return False, None
    return True, number


def build_starter_drivers():
    return {
        "D001": {"name": "Ali", "zone": "A", "available": True, "rating": 4.8},
        "D002": {"name": "Ahmed", "zone": "B", "available": True, "rating": 4.5},
        "D003": {"name": "Usman", "zone": "A", "available": False, "rating": 4.9},
        "D004": {"name": "Hamza", "zone": "A", "available": True, "rating": 4.2},
    }


def build_starter_deliveries():
    tasks = [
        {"id": "TASK001", "customer": "Customer A", "zone": "A", "distance": 4, "order_amount": 120, "priority": "normal", "status": "pending"},
        {"id": "TASK002", "customer": "Customer B", "zone": "B", "distance": 12, "order_amount": 80, "priority": "urgent", "status": "pending"},
        {"id": "TASK003", "customer": "Customer C", "zone": "A", "distance": 7, "order_amount": 200, "priority": "normal", "status": "pending"},
    ]
    for task in tasks:
        task["driver_id"] = None
    return tasks


def _valid_money_options(options, allowed):
    for key, value in options.items():
        if key not in allowed:
            return result(False, "Unknown pricing option: " + key)
        ok, number = to_number(value)
        if not ok or number < 0:
            return result(False, "Invalid pricing option: " + key)
    return result(True, "Options valid", {key: float(value) for key, value in options.items()})


def _tier_rate(distance, rates):
    if distance <= 5:
        return rates[0]
    if distance <= 10:
        return rates[1]
    return rates[2]


def calculate_delivery_charge(distance, priority, **options):
    ok, value = to_number(distance)
    if not ok or value < 0:
        return result(False, "Invalid distance")
    if not isinstance(priority, str) or priority.strip().lower() not in ("normal", "urgent"):
        return result(False, "Invalid priority")
    checked = _valid_money_options(options, ("base_charge", "urgent_surcharge"))
    if not checked["success"]:
        return checked
    base = checked["data"].get("base_charge", CONFIG["base_charge"])
    surcharge_rate = checked["data"].get("urgent_surcharge", CONFIG["urgent_surcharge"])
    rate = _tier_rate(value, CONFIG["delivery_rates"])
    distance_charge = value * rate
    subtotal = base + distance_charge
    surcharge = subtotal * surcharge_rate if priority.strip().lower() == "urgent" else 0.0
    return result(True, "Delivery charge calculated", {
        "base": round(base, 2), "distance": value, "rate": rate,
        "distance_charge": round(distance_charge, 2), "surcharge": round(surcharge, 2),
        "final_charge": round(subtotal + surcharge, 2),
    })


def calculate_driver_earning(distance, order_amount, **options):
    ok, distance_value = to_number(distance)
    if not ok or distance_value < 0:
        return result(False, "Invalid distance")
    ok, order_value = to_number(order_amount)
    if not ok or order_value <= 0:
        return result(False, "Invalid order amount")
    allowed = ("driver_base", "driver_bonus_percentage", "bonus_threshold")
    checked = _valid_money_options(options, allowed)
    if not checked["success"]:
        return checked
    config = checked["data"]
    base = config.get("driver_base", CONFIG["driver_base"])
    bonus_rate = config.get("driver_bonus_percentage", CONFIG["driver_bonus_percentage"])
    threshold = config.get("bonus_threshold", CONFIG["bonus_threshold"])
    rate = _tier_rate(distance_value, CONFIG["driver_rates"])
    distance_earning = distance_value * rate
    subtotal = base + distance_earning
    bonus = subtotal * bonus_rate if order_value >= threshold else 0.0
    return result(True, "Driver earning calculated", {
        "base": round(base, 2), "distance": distance_value, "rate": rate,
        "distance_earning": round(distance_earning, 2), "bonus": round(bonus, 2),
        "total": round(subtotal + bonus, 2),
    })


def calculate_total(*amounts):
    total = 0.0
    for amount in amounts:
        ok, number = to_number(amount)
        if not ok:
            return result(False, "Invalid amount in total")
        total += number
    return result(True, "Total calculated", round(total, 2))


def validate_driver(driver):
    if not isinstance(driver, dict):
        return result(False, "Driver must be a dictionary")
    for field in DRIVER_FIELDS:
        if field not in driver:
            return result(False, "Missing driver field: " + field)
    if not isinstance(driver["name"], str) or not driver["name"].strip():
        return result(False, "Invalid driver name")
    if not isinstance(driver["zone"], str) or not driver["zone"].strip():
        return result(False, "Invalid driver zone")
    if driver["available"] is not True and driver["available"] is not False:
        return result(False, "Driver availability must be boolean")
    ok, rating = to_number(driver["rating"])
    if not ok or rating < 0 or rating > 5:
        return result(False, "Invalid driver rating")
    return result(True, "Driver valid")


def validate_task(task, known_driver_ids=None):
    if not isinstance(task, dict):
        return result(False, "Task must be a dictionary")
    for field in TASK_FIELDS:
        if field not in task:
            return result(False, "Missing task field: " + field)
    if not isinstance(task["id"], str) or not task["id"].strip():
        return result(False, "Invalid task ID")
    if not isinstance(task["customer"], str) or not task["customer"].strip():
        return result(False, "Invalid customer")
    if not isinstance(task["zone"], str) or not task["zone"].strip():
        return result(False, "Invalid task zone")
    ok, distance = to_number(task["distance"])
    if not ok or distance < 0:
        return result(False, "Invalid distance")
    ok, amount = to_number(task["order_amount"])
    if not ok or amount <= 0:
        return result(False, "Invalid order amount")
    if not isinstance(task["priority"], str) or task["priority"].strip().lower() not in ("normal", "urgent"):
        return result(False, "Invalid priority")
    if not isinstance(task["status"], str) or task["status"].strip().lower() not in VALID_STATUSES:
        return result(False, "Invalid status")
    driver_id = task.get("driver_id")
    if task["status"].strip().lower() in ("assigned", "picked_up"):
        if driver_id is None or (known_driver_ids is not None and driver_id not in known_driver_ids):
            return result(False, "Active task has missing or unknown driver")
    return result(True, "Task valid")


def _index_tasks(deliveries, drivers=None):
    indexed = {}
    rejected = []
    driver_ids = drivers.keys() if isinstance(drivers, dict) else None
    if not isinstance(deliveries, list):
        return indexed, [{"task": None, "reason": "Deliveries must be a list"}]
    for task in deliveries:
        valid = validate_task(task, driver_ids)
        if not valid["success"]:
            rejected.append({"task": task, "reason": valid["message"]})
        elif task["id"] in indexed:
            rejected.append({"task": task, "reason": "Duplicate task ID: " + task["id"]})
        else:
            indexed[task["id"]] = task
    return indexed, rejected


def _validated_drivers(drivers):
    if not isinstance(drivers, dict):
        return result(False, "Drivers must be a dictionary")
    for driver_id, driver in drivers.items():
        valid = validate_driver(driver)
        if not valid["success"]:
            return result(False, "Invalid driver " + str(driver_id) + ": " + valid["message"])
    return result(True, "Drivers valid")


def _assign(drivers, task, driver_id):
    driver = drivers[driver_id]
    driver["available"] = False
    task["driver_id"] = driver_id
    task["status"] = "assigned"
    return result(True, "Task assigned successfully", {"task_id": task["id"], "driver_id": driver_id})


def assign_driver(drivers, deliveries, task_id, driver_id):
    valid_drivers = _validated_drivers(drivers)
    if not valid_drivers["success"]:
        return valid_drivers
    tasks, rejected = _index_tasks(deliveries, drivers)
    task = tasks.get(task_id)
    if task is None:
        return result(False, "Invalid task ID" if not rejected else "Invalid task ID or task data")
    if driver_id not in drivers:
        return result(False, "Invalid driver ID")
    if task["status"].strip().lower() != "pending":
        return result(False, "Task is not pending")
    if task.get("driver_id") is not None:
        return result(False, "Task already has a driver")
    driver = drivers[driver_id]
    if not driver["available"]:
        return result(False, "Driver is unavailable or busy")
    if driver["zone"].strip().upper() != task["zone"].strip().upper():
        return result(False, "Driver is in another zone")
    return _assign(drivers, task, driver_id)


def allocate_driver(drivers, deliveries, task_id):
    valid_drivers = _validated_drivers(drivers)
    if not valid_drivers["success"]:
        return valid_drivers
    tasks, rejected = _index_tasks(deliveries, drivers)
    task = tasks.get(task_id)
    if task is None:
        return result(False, "Invalid task ID" if not rejected else "Invalid task ID or task data")
    if task["status"].strip().lower() != "pending":
        return result(False, "Task is not pending")
    if task.get("driver_id") is not None:
        return result(False, "Task already has a driver")
    eligible = [
        (driver_id, driver) for driver_id, driver in drivers.items()
        if driver["available"] and driver["zone"].strip().upper() == task["zone"].strip().upper()
    ]
    if not eligible:
        return result(False, "No available driver found in task zone")
    driver_id, driver = sorted(eligible, key=lambda item: (-float(item[1]["rating"]), item[0]))[0]
    return _assign(drivers, task, driver_id)


def allocate_pending_tasks(drivers, deliveries):
    valid_drivers = _validated_drivers(drivers)
    if not valid_drivers["success"]:
        return valid_drivers
    tasks, rejected = _index_tasks(deliveries, drivers)
    ordered = sorted(
        [task for task in tasks.values() if task["status"].strip().lower() == "pending" and task.get("driver_id") is None],
        key=lambda task: (0 if task["priority"].strip().lower() == "urgent" else 1, task["id"]),
    )
    outcomes = []
    for task in ordered:
        outcomes.append(allocate_driver(drivers, deliveries, task["id"]))
    return result(True, "Batch allocation completed", {"assignments": outcomes, "rejected_tasks": rejected})


def update_delivery_status(drivers, deliveries, task_id, new_status):
    if not isinstance(new_status, str) or new_status.strip().lower() not in VALID_STATUSES:
        return result(False, "Invalid status")
    tasks, rejected = _index_tasks(deliveries, drivers)
    task = tasks.get(task_id)
    if task is None:
        return result(False, "Invalid task ID" if not rejected else "Invalid task ID or task data")
    old = task["status"].strip().lower()
    new = new_status.strip().lower()
    if old == "pending" and new == "assigned":
        return result(False, "Use driver assignment to move a pending task to assigned")
    transitions = {"assigned": ("picked_up",), "picked_up": ("delivered", "failed")}
    if new not in transitions.get(old, ()):
        return result(False, "Invalid status transition")
    task["status"] = new
    if new in ("delivered", "failed"):
        driver_id = task.get("driver_id")
        if driver_id in drivers:
            drivers[driver_id]["available"] = True
    return result(True, "Task status updated", {"task_id": task_id, "status": new})


def task_delivery_charge(task):
    if not isinstance(task, dict):
        return result(False, "Task must be a dictionary")
    valid = validate_task(task)
    if not valid["success"]:
        return valid
    return calculate_delivery_charge(task["distance"], task["priority"])


def task_driver_earning(task):
    if not isinstance(task, dict):
        return result(False, "Task must be a dictionary")
    valid = validate_task(task)
    if not valid["success"]:
        return valid
    if task["status"].strip().lower() == "failed":
        return result(True, "Failed deliveries earn zero", {"base": 0.0, "distance": float(task["distance"]), "rate": 0.0, "distance_earning": 0.0, "bonus": 0.0, "total": 0.0})
    return calculate_driver_earning(task["distance"], task["order_amount"])


def driver_performance_report(drivers, deliveries):
    tasks, rejected = _index_tasks(deliveries, drivers)
    rows = {}
    for driver_id, driver in drivers.items():
        assigned = [task for task in tasks.values() if task.get("driver_id") == driver_id]
        delivered = [task for task in assigned if task["status"].strip().lower() == "delivered"]
        failed = [task for task in assigned if task["status"].strip().lower() == "failed"]
        earnings = [task_driver_earning(task)["data"]["total"] for task in delivered]
        total_earning = calculate_total(*earnings)["data"]
        total_distance = calculate_total(*(task["distance"] for task in delivered))["data"]
        rows[driver_id] = {
            "driver_id": driver_id, "name": driver.get("name", ""), "zone": driver.get("zone", ""),
            "total_assigned": len(assigned), "delivered": len(delivered), "failed": len(failed),
            "total_distance": round(total_distance, 2), "total_earnings": total_earning,
            "completion_rate": (len(delivered) / len(assigned) * 100) if assigned else 0.0,
        }
    return result(True, "Driver performance report generated", {"drivers": rows, "rejected_tasks": rejected})


def zone_report(drivers, deliveries):
    tasks, rejected = _index_tasks(deliveries, drivers)
    zones = {task["zone"].strip().upper() for task in tasks.values()}
    if isinstance(drivers, dict):
        zones.update(driver["zone"].strip().upper() for driver in drivers.values() if isinstance(driver, dict) and isinstance(driver.get("zone"), str) and driver["zone"].strip())
    rows = {}
    for zone in zones:
        zone_tasks = [task for task in tasks.values() if task["zone"].strip().upper() == zone]
        charges = [task_delivery_charge(task)["data"]["final_charge"] for task in zone_tasks if task["status"].strip().lower() == "delivered"]
        rows[zone] = {"zone": zone, "total_tasks": len(zone_tasks), "delivered_revenue": calculate_total(*charges)["data"], "delivered_tasks": sum(1 for task in zone_tasks if task["status"].strip().lower() == "delivered")}
    ordered = sorted(rows.values(), key=lambda row: (-row["delivered_revenue"], row["zone"]))
    return result(True, "Zone report generated", {"zones": ordered, "rejected_tasks": rejected})


def additional_reports(drivers, deliveries):
    tasks, rejected = _index_tasks(deliveries, drivers)
    valid_tasks = list(tasks.values())
    zones = {task["zone"].strip().upper() for task in valid_tasks}
    if isinstance(drivers, dict):
        zones.update(driver["zone"].strip().upper() for driver in drivers.values() if isinstance(driver, dict) and isinstance(driver.get("zone"), str) and driver["zone"].strip())
    counts = {zone: sum(1 for task in valid_tasks if task["zone"].strip().upper() == zone) for zone in sorted(zones)}
    revenues = {}
    for zone in sorted(zones):
        amounts = [task_delivery_charge(task)["data"]["final_charge"] for task in valid_tasks if task["zone"].strip().upper() == zone and task["status"].strip().lower() == "delivered"]
        revenues[zone] = calculate_total(*amounts)["data"]
    order_values = [float(task["order_amount"]) for task in valid_tasks]
    distances = [float(task["distance"]) for task in valid_tasks]
    longest = max(valid_tasks, key=lambda task: (float(task["distance"]), task["id"])) if valid_tasks else None
    highest = max(valid_tasks, key=lambda task: (float(task["order_amount"]), task["id"])) if valid_tasks else None
    return result(True, "Additional reports generated", {
        "unique_zones": sorted(zones), "tasks_per_zone": counts, "revenue_per_zone": revenues,
        "average_order_amount": calculate_total(*order_values)["data"] / len(order_values) if order_values else 0.0,
        "longest_delivery": longest, "highest_value_order": highest,
        "available_drivers": [driver_id for driver_id, driver in drivers.items() if driver["available"]],
        "busy_drivers": [driver_id for driver_id, driver in drivers.items() if not driver["available"]],
        "urgent_deliveries": [task["id"] for task in valid_tasks if task["priority"].strip().lower() == "urgent"],
        "unassigned_tasks": [task["id"] for task in valid_tasks if task["status"].strip().lower() == "pending" and task.get("driver_id") is None],
        "rejected_tasks": rejected,
    })


def dashboard_data(drivers, deliveries):
    tasks, rejected = _index_tasks(deliveries, drivers)
    valid_tasks = list(tasks.values())
    statuses = {status: sum(1 for task in valid_tasks if task["status"].strip().lower() == status) for status in VALID_STATUSES}
    order_value = calculate_total(*(task["order_amount"] for task in valid_tasks))["data"]
    delivered = [task for task in valid_tasks if task["status"].strip().lower() == "delivered"]
    charges = [task_delivery_charge(task)["data"]["final_charge"] for task in delivered]
    earnings = [task_driver_earning(task)["data"]["total"] for task in delivered]
    performance = driver_performance_report(drivers, deliveries)["data"]["drivers"]
    qualifying = [row for row in performance.values() if row["delivered"] > 0]
    top = sorted(qualifying, key=lambda row: (-row["delivered"], -row["total_earnings"], row["driver_id"]))[0]["driver_id"] if qualifying else "N/A"
    zone_revenue = {}
    for task in delivered:
        zone = task["zone"].strip().upper()
        zone_revenue.setdefault(zone, []).append(task_delivery_charge(task)["data"]["final_charge"])
    totals = {zone: calculate_total(*amounts)["data"] for zone, amounts in zone_revenue.items()}
    best_zone = sorted(totals, key=lambda zone: (-totals[zone], zone))[0] if totals and max(totals.values()) > 0 else "N/A"
    distance_total = calculate_total(*(task["distance"] for task in valid_tasks))["data"]
    unassigned = [task["id"] for task in valid_tasks if task["status"].strip().lower() == "pending" and task.get("driver_id") is None]
    return result(True, "Dashboard generated", {
        "total_tasks": len(valid_tasks), "statuses": statuses, "total_order_value": order_value,
        "total_delivery_charges": calculate_total(*charges)["data"], "total_driver_earnings": calculate_total(*earnings)["data"],
        "top_driver": top, "highest_revenue_zone": best_zone,
        "average_delivery_distance": distance_total / len(valid_tasks) if valid_tasks else 0.0,
        "unassigned_tasks": unassigned, "rejected_tasks": rejected,
    })


def render_dashboard(data):
    lines = [
        "========== DELIVERY DASHBOARD ==========", "Total Tasks: {}".format(data["total_tasks"]),
        "Pending: {}".format(data["statuses"]["pending"]), "Assigned: {}".format(data["statuses"]["assigned"]),
        "Picked Up: {}".format(data["statuses"]["picked_up"]), "Delivered: {}".format(data["statuses"]["delivered"]),
        "Failed: {}".format(data["statuses"]["failed"]), "Total Order Value: ${:.2f}".format(data["total_order_value"]),
        "Total Delivery Charges: ${:.2f}".format(data["total_delivery_charges"]),
        "Total Driver Earnings: ${:.2f}".format(data["total_driver_earnings"]), "Top Driver: {}".format(data["top_driver"]),
        "Highest Revenue Zone: {}".format(data["highest_revenue_zone"]),
        "Average Delivery Distance: {:.2f} km".format(data["average_delivery_distance"]), "Unassigned Tasks:",
    ]
    lines.extend("- " + task_id for task_id in data["unassigned_tasks"] or ["None"])
    lines.append("========================================")
    return "\n".join(lines)


def make_rate_calculator(tiers, base):
    """Return a calculator that closes over tiers/base and uses global CONFIG defaults."""
    def calculate(distance):
        ok, number = to_number(distance)
        if not ok or number < 0:
            return result(False, "Invalid distance")
        return result(True, "Rate calculated", base + number * _tier_rate(number, tiers) + CONFIG["base_charge"] * 0)
    return calculate


def explain_legb_demo():
    scope_name = "global configuration"
    def enclosing():
        scope_name = "enclosing function"
        def local():
            scope_name = "local variable"
            return {"local": scope_name, "enclosing": enclosing_name, "global": CONFIG["base_charge"], "built_in": len((1, 2, 3))}
        enclosing_name = scope_name
        return local()
    return enclosing()


def _print_result(operation):
    print(("SUCCESS: " if operation["success"] else "REJECTED: ") + operation["message"])


def main():
    drivers = build_starter_drivers()
    deliveries = build_starter_deliveries()
    print("=== DRIVER ALLOCATION ===")
    allocation = allocate_pending_tasks(drivers, deliveries)
    for item in allocation["data"]["assignments"]:
        _print_result(item)
        if item["success"]:
            print("{} -> {}".format(drivers[item["data"]["driver_id"]]["name"], item["data"]["task_id"]))
    update_delivery_status(drivers, deliveries, "TASK001", "picked_up")
    update_delivery_status(drivers, deliveries, "TASK001", "delivered")
    update_delivery_status(drivers, deliveries, "TASK003", "picked_up")
    update_delivery_status(drivers, deliveries, "TASK003", "failed")
    deliveries.append({"id": "TASK004", "customer": "Customer D", "zone": "C", "distance": 0, "order_amount": 50, "priority": "normal", "status": "pending", "driver_id": None})
    _print_result(allocate_driver(drivers, deliveries, "TASK004"))
    print("=== REJECTED OPERATIONS ===")
    for operation in (
        assign_driver(drivers, deliveries, "MISSING", "D001"),
        assign_driver(drivers, deliveries, "TASK004", "D003"),
        update_delivery_status(drivers, deliveries, "TASK002", "delivered"),
        allocate_driver(drivers, deliveries, "TASK001"),
        calculate_delivery_charge(-1, "normal"),
    ):
        _print_result(operation)
    print("=== DELIVERY CHARGES ===")
    for task in deliveries:
        charge = task_delivery_charge(task)
        if charge["success"]:
            print("{}: ${:.2f}".format(task["id"], charge["data"]["final_charge"]))
    print("=== DRIVER EARNINGS ===")
    for task in deliveries:
        earning = task_driver_earning(task)
        if earning["success"]:
            print("{}: ${:.2f}".format(task["id"], earning["data"]["total"]))
    print("=== DRIVER PERFORMANCE ===")
    for driver_id, row in driver_performance_report(drivers, deliveries)["data"]["drivers"].items():
        print("{} {} delivered={} failed={} earnings=${:.2f} completion={:.2f}%".format(driver_id, row["name"], row["delivered"], row["failed"], row["total_earnings"], row["completion_rate"]))
    print("=== ZONE REPORT ===")
    for row in zone_report(drivers, deliveries)["data"]["zones"]:
        print("{} tasks={} revenue=${:.2f}".format(row["zone"], row["total_tasks"], row["delivered_revenue"]))
    print("=== ADDITIONAL REPORTS ===")
    print(additional_reports(drivers, deliveries)["data"])
    print("=== DELIVERY DASHBOARD ===")
    print(render_dashboard(dashboard_data(drivers, deliveries)["data"]))
    print("=== LEGB DEMO ===")
    print(explain_legb_demo())


if __name__ == "__main__":
    main()
