from delivery_system import (
    additional_reports, allocate_driver, allocate_pending_tasks, assign_driver,
    build_starter_deliveries, build_starter_drivers, calculate_delivery_charge,
    calculate_driver_earning, calculate_total, dashboard_data, driver_performance_report,
    task_driver_earning, update_delivery_status, validate_task, zone_report,
)


def _task(task_id="X", **changes):
    task = {"id": task_id, "customer": "Test", "zone": "A", "distance": 4,
            "order_amount": 120, "priority": "normal", "status": "pending", "driver_id": None}
    task.update(changes)
    return task


def test_fresh_starter_data():
    first = build_starter_drivers()
    second = build_starter_drivers()
    first["D001"]["available"] = False
    assert second["D001"]["available"] is True
    one = build_starter_deliveries()
    two = build_starter_deliveries()
    one[0]["driver_id"] = "D001"
    assert two[0]["driver_id"] is None


def test_allocation_and_tie_break():
    drivers = {"D004": {"name": "Four", "zone": "A", "available": True, "rating": 4.5},
               "D001": {"name": "One", "zone": "A", "available": True, "rating": 4.5}}
    tasks = [_task()]
    assigned = allocate_driver(drivers, tasks, "X")
    assert assigned["success"] and assigned["data"]["driver_id"] == "D001"
    assert tasks[0]["status"] == "assigned" and drivers["D001"]["available"] is False


def test_allocation_validation_and_no_driver():
    drivers = build_starter_drivers()
    task = _task(zone="C")
    assert allocate_driver(drivers, [task], "X")["message"] == "No available driver found in task zone"
    assert task["status"] == "pending"
    assert assign_driver(drivers, [task], "bad", "D001")["message"] == "Invalid task ID"
    assert assign_driver(drivers, [task], "X", "bad")["message"] == "Invalid driver ID"
    assert assign_driver(drivers, [task], "X", "D001")["message"] == "Driver is in another zone"
    task["driver_id"] = "D001"
    assert allocate_driver(drivers, [task], "X")["message"] == "Task already has a driver"


def test_batch_priority_and_multiple_tasks():
    drivers = build_starter_drivers()
    tasks = [_task("N", zone="A"), _task("U", zone="B", priority="urgent")]
    outcome = allocate_pending_tasks(drivers, tasks)
    assert outcome["success"]
    assignments = outcome["data"]["assignments"]
    assert [row["data"]["task_id"] for row in assignments] == ["U", "N"]
    assert tasks[0]["driver_id"] == "D001" and tasks[1]["driver_id"] == "D002"


def test_pricing_tiers_zero_and_options():
    assert calculate_delivery_charge(0, "normal")["data"]["final_charge"] == 5.0
    assert calculate_delivery_charge(4, "normal")["data"]["final_charge"] == 9.0
    assert calculate_delivery_charge(7, "normal")["data"]["distance_charge"] == 10.5
    assert calculate_delivery_charge(12, "normal")["data"]["distance_charge"] == 24.0
    urgent = calculate_delivery_charge(4, "urgent")
    assert urgent["data"]["surcharge"] == 2.25 and urgent["data"]["final_charge"] == 11.25
    assert calculate_delivery_charge(1, "normal", base_charge=10)["data"]["final_charge"] == 11.0
    assert calculate_delivery_charge(1, "normal", unknown=1)["success"] is False
    assert calculate_delivery_charge(True, "normal")["success"] is False


def test_earnings_and_totals():
    assert calculate_driver_earning(0, 149)["data"]["total"] == 3.0
    assert calculate_driver_earning(4, 120)["data"]["total"] == 6.2
    assert calculate_driver_earning(7, 150)["data"]["total"] == 12.54
    assert calculate_driver_earning(12, 100)["data"]["distance_earning"] == 18.0
    assert calculate_driver_earning(0, 150)["data"]["total"] == 3.3
    assert calculate_driver_earning(1, 100, driver_base=4)["data"]["base"] == 4
    assert calculate_driver_earning(1, 100, odd_option=1)["success"] is False
    assert calculate_total(1, "2", 3)["data"] == 6.0
    assert calculate_total(True)["success"] is False
    assert task_driver_earning(_task(status="failed"))["data"]["total"] == 0.0


def test_validation_and_input_integrity():
    good = _task()
    assert validate_task(good)["success"]
    for value in (True, "nope", float("nan"), float("inf"), -1):
        assert validate_task(_task(distance=value))["success"] is False
    for value in (False, "NaN", 0, -2):
        assert validate_task(_task(order_amount=value))["success"] is False
    missing = _task()
    del missing["customer"]
    assert validate_task(missing)["message"] == "Missing task field: customer"
    active = _task(status="assigned")
    assert validate_task(active)["success"] is False
    drivers = build_starter_drivers()
    duplicate = [_task("DUP"), _task("DUP")]
    report = dashboard_data(drivers, duplicate)
    assert report["data"]["total_tasks"] == 1
    assert report["data"]["rejected_tasks"][0]["reason"] == "Duplicate task ID: DUP"


def test_workflow_and_availability():
    drivers = build_starter_drivers()
    tasks = [_task()]
    assert update_delivery_status(drivers, tasks, "X", "picked_up")["success"] is False
    assert assign_driver(drivers, tasks, "X", "D001")["success"]
    assert update_delivery_status(drivers, tasks, "X", "picked_up")["success"]
    assert update_delivery_status(drivers, tasks, "X", "delivered")["success"]
    assert drivers["D001"]["available"] is True
    assert update_delivery_status(drivers, tasks, "X", "delivered")["success"] is False
    tasks = [_task()]
    assert assign_driver(drivers, tasks, "X", "D001")["success"]
    assert update_delivery_status(drivers, tasks, "X", "picked_up")["success"]
    assert update_delivery_status(drivers, tasks, "X", "failed")["success"]
    assert drivers["D001"]["available"] is True
    assert update_delivery_status(drivers, tasks, "X", "pending")["success"] is False


def test_reports_and_dashboard():
    drivers = build_starter_drivers()
    tasks = build_starter_deliveries()
    allocate_pending_tasks(drivers, tasks)
    update_delivery_status(drivers, tasks, "TASK001", "picked_up")
    update_delivery_status(drivers, tasks, "TASK001", "delivered")
    update_delivery_status(drivers, tasks, "TASK003", "picked_up")
    update_delivery_status(drivers, tasks, "TASK003", "failed")
    performance = driver_performance_report(drivers, tasks)["data"]["drivers"]
    assert len(performance) == 4 and performance["D001"]["delivered"] == 1
    assert performance["D003"]["total_assigned"] == 0
    assert zone_report(drivers, tasks)["data"]["zones"]
    extra = additional_reports(drivers, tasks)["data"]
    assert "A" in extra["unique_zones"] and extra["longest_delivery"]["id"] == "TASK002"
    board = dashboard_data(drivers, tasks)["data"]
    assert board["total_tasks"] == 3 and board["statuses"]["delivered"] == 1
    assert board["top_driver"] == "D001" and board["highest_revenue_zone"] == "A"


def run_tests():
    tests = [test_fresh_starter_data, test_allocation_and_tie_break, test_allocation_validation_and_no_driver,
             test_batch_priority_and_multiple_tasks, test_pricing_tiers_zero_and_options, test_earnings_and_totals,
             test_validation_and_input_integrity, test_workflow_and_availability, test_reports_and_dashboard]
    print("Running tests...")
    for test in tests:
        test()
        print("PASS: " + test.__name__)
    print("All tests passed.")


if __name__ == "__main__":
    run_tests()
